// ===== Configuración: editá estos datos =====
const CONFIG = {
  whatsapp: "5491139027103", // código de país + área + número, sin "+" ni espacios
  mensaje: "Hola Dr. Brambilla, le escribo desde su web. Quería consultarle sobre…",
};

const waLink = (text) =>
  `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(text)}`;

// Todos los botones con data-wa abren WhatsApp
document.querySelectorAll("[data-wa]").forEach((el) => {
  el.href = waLink(CONFIG.mensaje);
  el.target = "_blank";
  el.rel = "noopener";
});

// El logo vuelve al principio de la página (el ancla #top apunta al
// encabezado fijo, que siempre está a la vista, por eso no alcanzaba)
document.querySelector(".brand").addEventListener("click", (e) => {
  e.preventDefault();
  window.scrollTo({ top: 0, behavior: "smooth" });
  history.replaceState(null, "", location.pathname);
});

// Menú móvil
const toggle = document.querySelector(".nav-toggle");
const nav = document.querySelector(".nav");

toggle.addEventListener("click", () => {
  const open = nav.classList.toggle("is-open");
  toggle.setAttribute("aria-expanded", open);
  toggle.setAttribute("aria-label", open ? "Cerrar menú" : "Abrir menú");
});

nav.querySelectorAll("a").forEach((a) =>
  a.addEventListener("click", () => {
    nav.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", false);
  })
);

// Formulario: arma el mensaje y lo envía por WhatsApp
document.getElementById("contact-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const data = new FormData(e.target);
  const text =
    `Hola Dr. Brambilla, soy ${data.get("nombre")}.\n` +
    `Tema: ${data.get("tema")}\n\n` +
    data.get("mensaje");
  window.open(waLink(text), "_blank", "noopener");
});

document.getElementById("year").textContent = new Date().getFullYear();
